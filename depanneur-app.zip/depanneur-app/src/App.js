import React, { useState, useEffect } from 'react';
import { 
  ShoppingCart, Package, FileText, AlertTriangle, Plus, Trash2, 
  CreditCard, CheckCircle, XCircle, RefreshCw, BarChart3, 
  Lock, User, Shield, Archive, ArrowRight, CheckSquare, Box, Hash, Mail, Send, Sparkles, Lightbulb, DollarSign, Calendar, Printer, Share, List, FileCheck, Star, ThumbsUp, ThumbsDown, TrendingUp, Eye, Undo2, History
} from 'lucide-react';

// --- GEMINI API HELPER ---
const callGeminiAPI = async (prompt) => {
  const apiKey = ""; // API Key injected at runtime
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    });
    
    if (!response.ok) throw new Error("AI Service Unavailable");
    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error("AI Error:", error);
    return "Sorry, Jeannot's brain is fuzzy right now. Please try again.";
  }
};

// --- UTILITY COMPONENTS ---

function StepPill({ num, label, active, done }) {
  return (
    <div className={`flex items-center px-3 py-1 rounded-full text-xs font-bold transition-colors
      ${active ? 'bg-blue-600 text-white' : done ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-400'}
    `}>
      <span className={`mr-2 w-5 h-5 rounded-full flex items-center justify-center ${active ? 'bg-white text-blue-600' : 'bg-gray-200'}`}>
        {done ? <CheckCircle size={12}/> : num}
      </span>
      {label}
    </div>
  )
}

function DashboardCard({ title, value, sub, color, icon }) {
  return (
    <div className={`${color} rounded-xl p-6 text-white shadow-lg relative overflow-hidden`}>
      <div className="relative z-10">
        <div className="text-blue-100 text-sm font-medium mb-1">{title}</div>
        <div className="text-3xl font-bold mb-1">{value}</div>
        <div className="text-xs text-white opacity-70">{sub}</div>
      </div>
      <div className="absolute right-4 bottom-4 opacity-20 transform scale-150">{icon}</div>
    </div>
  )
}

function NavButton({ active, onClick, icon, label, special }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center px-3 py-2 rounded-md transition-all text-sm font-medium whitespace-nowrap
        ${active 
          ? special ? 'bg-purple-600 text-white shadow-lg' : 'bg-blue-500 text-white shadow-lg' 
          : 'text-slate-400 hover:text-white hover:bg-slate-700'}
      `}
    >
      {icon}
      <span className="ml-2 hidden lg:block">{label}</span>
    </button>
  )
}

function StepIndicator({ num, label, active, done }) {
  return (
    <div className="flex flex-col items-center relative z-10">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold mb-2 transition-all
        ${done ? 'bg-emerald-500 text-white' : active ? 'bg-purple-600 text-white scale-110 ring-4 ring-purple-100' : 'bg-gray-200 text-gray-500'}
      `}>
        {done ? <CheckCircle size={20}/> : num}
      </div>
      <span className={`text-xs font-bold ${active ? 'text-purple-700' : 'text-gray-400'}`}>{label}</span>
    </div>
  )
}

// --- MOCK DATA STORES ---

const INITIAL_INVENTORY = [
  { sku: 'COKE500', name: 'Coke 500ml', price: 2.50, cost: 1.20, stock: 12, reorderPoint: 24, category: 'Beverage', restricted: false, supplier: 'ABC Beverages', supplierScore: 4.8, ratings: 20 },
  { sku: 'CHIPS200', name: 'Chips 200g', price: 3.99, cost: 1.50, stock: 3, reorderPoint: 10, category: 'Snack', restricted: false, supplier: 'SnackCo', supplierScore: 3.5, ratings: 12 }, 
  { sku: 'BEER6PK', name: 'Local Beer 6pk', price: 14.50, cost: 8.50, stock: 20, reorderPoint: 10, category: 'Alcohol', restricted: true, supplier: 'Local Brewery', supplierScore: 5.0, ratings: 8 },
  { sku: 'WINE750', name: 'Red Wine 750ml', price: 18.00, cost: 11.00, stock: 8, reorderPoint: 5, category: 'Alcohol', restricted: true, supplier: 'Vin Quebec', supplierScore: 4.2, ratings: 15 },
  { sku: 'CIG20', name: 'Cigarettes 20pk', price: 12.00, cost: 9.50, stock: 50, reorderPoint: 20, category: 'Tobacco', restricted: true, supplier: 'Imperial Tobacco', supplierScore: 4.9, ratings: 30 },
  { sku: 'LOTTO649', name: 'Lotto 6/49', price: 5.00, cost: 4.50, stock: 999, reorderPoint: 0, category: 'Lottery', restricted: true, supplier: 'Loto-Quebec', supplierScore: 5.0, ratings: 50 },
  { sku: 'SCRATCH', name: 'Scratch Card', price: 2.00, cost: 1.80, stock: 100, reorderPoint: 20, category: 'Lottery', restricted: true, supplier: 'Loto-Quebec', supplierScore: 5.0, ratings: 50 },
];

const INITIAL_INVOICES = [
  { id: 'INV-884', supplier: 'ABC Beverages', date: '2025-06-20', amount: 240.00, status: 'Pending', items: [{name: 'Coke 500ml', qty: 48, price: 5.00}] },
  { id: 'INV-889', supplier: 'SnackCo', date: '2025-06-21', amount: 142.50, status: 'Pending', items: [{name: 'Chips 200g', qty: 50, price: 2.85}] },
  { id: 'INV-901', supplier: 'Local Brewery', date: '2025-06-22', amount: 560.00, status: 'Paid', items: [{name: 'Local Beer 6pk', qty: 40, price: 14.00}] },
];

const MOCK_MONTHLY_DATA = Array.from({ length: 29 }, (_, i) => {
  const sales = 2000 + Math.random() * 500;
  return {
    date: `2025-06-${i + 1}`,
    sales: sales,
    cost: sales * 0.65,
    tax: 300 + Math.random() * 50,
    variances: Math.random() > 0.8 ? 15.50 : 0 
  };
});

// --- MAIN APP COMPONENT ---

export default function App() {
  const [user, setUser] = useState(null); 
  const [activeTab, setActiveTab] = useState('dashboard'); 
  const [inventory, setInventory] = useState(INITIAL_INVENTORY);
  const [cart, setCart] = useState([]);
  const [salesLog, setSalesLog] = useState([]); 
  const [invoices, setInvoices] = useState(INITIAL_INVOICES); 
  const [returnsLog, setReturnsLog] = useState([]); // Log for returns/refunds
  const [spoilageLog, setSpoilageLog] = useState([]); // Log for spoiled items
  const [notification, setNotification] = useState(null);

  const handleLogin = (role) => {
    setUser({ 
      name: role === 'Owner' ? 'Michel Sameen (Owner)' : 'Michel (Clerk)', 
      role 
    });
    setActiveTab('dashboard');
  };

  const showNotification = (msg) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  if (!user) return <LoginScreen onLogin={handleLogin} />;

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-800 flex flex-col">
      
      {/* HEADER */}
      <header className="bg-slate-900 text-white shadow-xl z-10">
        <div className="container mx-auto px-6 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Shield size={24} className="text-white"/>
            </div>
            <div>
              {/* UPDATE: NEW NAME */}
              <h1 className="text-xl font-bold tracking-wider">DÉPANNEUR CHEZ JEANNOT</h1>
              <p className="text-[10px] text-blue-200 uppercase tracking-widest">Integrated Management System</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <nav className="flex space-x-1 bg-slate-800 p-1 rounded-lg overflow-x-auto">
              <NavButton active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<BarChart3 size={16} />} label="Dash" />
              <NavButton active={activeTab === 'pos'} onClick={() => setActiveTab('pos')} icon={<ShoppingCart size={16} />} label="POS" />
              <NavButton active={activeTab === 'returns'} onClick={() => setActiveTab('returns')} icon={<Undo2 size={16} />} label="Returns" />
              <NavButton active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')} icon={<Package size={16} />} label="Stock" />
              <NavButton active={activeTab === 'invoices'} onClick={() => setActiveTab('invoices')} icon={<FileCheck size={16} />} label="Invoices" />
              <NavButton active={activeTab === 'reports'} onClick={() => setActiveTab('reports')} icon={<FileText size={16} />} label="EOD (P4)" />
              
              {user.role === 'Owner' && (
                <NavButton 
                  active={activeTab === 'monthend'} 
                  onClick={() => setActiveTab('monthend')} 
                  icon={<Archive size={16} />} 
                  label="Month-End (P5)" 
                  special
                />
              )}
            </nav>

            <div className="flex items-center space-x-3 border-l border-slate-700 pl-6">
              <div className="text-right hidden md:block">
                <div className="text-sm font-bold text-blue-100">{user.name}</div>
                <div className="text-xs text-slate-400">{user.role === 'Owner' ? 'Admin Access' : 'Standard Access'}</div>
              </div>
              <button onClick={() => setUser(null)} className="p-2 hover:bg-slate-700 rounded-full transition">
                <Lock size={18} className="text-red-400" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="container mx-auto px-6 py-8 flex-1">
        {notification && (
          <div className="fixed top-24 right-6 bg-emerald-600 text-white px-6 py-4 rounded-lg shadow-2xl flex items-center animate-bounce z-50">
            <CheckCircle className="mr-3"/> {notification}
          </div>
        )}

        {activeTab === 'dashboard' && <Dashboard inventory={inventory} salesLog={salesLog} user={user} setTab={setActiveTab} invoices={invoices} returnsLog={returnsLog} />}
        {activeTab === 'pos' && <POS inventory={inventory} setInventory={setInventory} cart={cart} setCart={setCart} salesLog={salesLog} setSalesLog={setSalesLog} notify={showNotification} />}
        {activeTab === 'returns' && <Returns inventory={inventory} setInventory={setInventory} returnsLog={returnsLog} setReturnsLog={setReturnsLog} setSpoilageLog={setSpoilageLog} notify={showNotification} />}
        {activeTab === 'inventory' && <Inventory inventory={inventory} setInventory={setInventory} notify={showNotification} />}
        {activeTab === 'invoices' && <InvoicesList invoices={invoices} setInvoices={setInvoices} notify={showNotification} />}
        {activeTab === 'reports' && <EndOfDayReconciliation salesLog={salesLog} inventory={inventory} returnsLog={returnsLog} notify={showNotification} />}
        {activeTab === 'monthend' && <MonthEndReconciliation mockData={MOCK_MONTHLY_DATA} notify={showNotification} />}

      </main>
    </div>
  );
}

// --- SUB-COMPONENTS ---

function LoginScreen({ onLogin }) {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        <div className="bg-blue-600 p-8 text-center">
          <Shield size={48} className="text-white mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white">DÉPANNEUR CHEZ JEANNOT</h1>
          <p className="text-blue-100 mt-2">Secure System Login</p>
        </div>
        <div className="p-8 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select User Role</label>
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => onLogin('Clerk')} className="flex flex-col items-center p-4 border-2 border-gray-100 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition group">
                <User size={32} className="text-gray-400 group-hover:text-blue-600 mb-2" />
                <span className="font-bold text-gray-700">Clerk</span>
                <span className="text-xs text-gray-400">POS & Stock</span>
              </button>
              <button onClick={() => onLogin('Owner')} className="flex flex-col items-center p-4 border-2 border-gray-100 rounded-xl hover:border-purple-500 hover:bg-purple-50 transition group">
                <Lock size={32} className="text-gray-400 group-hover:text-purple-600 mb-2" />
                <span className="font-bold text-gray-700">Owner</span>
                <span className="text-xs text-gray-400">Full Access (P5)</span>
              </button>
            </div>
          </div>
          <p className="text-center text-xs text-gray-400">Simulation Mode: No password required</p>
        </div>
      </div>
    </div>
  );
}

function Dashboard({ inventory, salesLog, user, setTab, invoices, returnsLog }) {
  const lowStockItems = inventory.filter(i => i.stock <= i.reorderPoint);
  const lowStockCount = lowStockItems.length;
  const dailyTotal = salesLog.reduce((acc, s) => acc + s.totals.total, 0);
  const pendingInvoices = invoices.filter(i => i.status === 'Pending').length;
  const totalRefunds = (returnsLog || []).reduce((acc, r) => acc + r.amount, 0);
  
  const [showLowStock, setShowLowStock] = useState(false);

  return (
    <div className="space-y-6 relative">
      <h2 className="text-2xl font-bold text-gray-800">Welcome back, {user.name.split(' ')[0]}</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <DashboardCard 
          title="Today's Sales" 
          value={`$${(dailyTotal - totalRefunds).toFixed(2)}`} 
          sub="Net Revenue (Post-Refunds)"
          color="bg-emerald-500" 
          icon={<CreditCard className="text-white opacity-80" size={32} />}
        />
        <div className={`bg-red-500 rounded-xl p-6 text-white shadow-lg relative overflow-hidden`}>
          <div className="relative z-10">
            <div className="text-blue-100 text-sm font-medium mb-1">Inventory Alerts</div>
            <div className="text-3xl font-bold mb-1">{lowStockCount}</div>
            <div className="text-xs text-white opacity-70">Items below reorder point</div>
            <button 
              onClick={() => setShowLowStock(!showLowStock)}
              className="mt-3 bg-white/20 hover:bg-white/30 text-xs font-bold py-1 px-3 rounded flex items-center"
            >
              <Eye size={12} className="mr-1"/> View Items
            </button>
          </div>
          <div className="absolute right-4 bottom-4 opacity-20 transform scale-150"><AlertTriangle className="text-white opacity-80" size={32} /></div>
        </div>
         <DashboardCard 
          title="Pending Invoices" 
          value={pendingInvoices} 
          sub="To Review & Pay"
          color="bg-blue-500" 
          icon={<FileText className="text-white opacity-80" size={32} />}
        />
        <DashboardCard 
          title="Month Status" 
          value="Open" 
          sub="June 2025"
          color="bg-purple-500" 
          icon={<Archive className="text-white opacity-80" size={32} />}
        />
      </div>

      {/* Low Stock Modal */}
      {showLowStock && (
        <div className="absolute top-20 left-0 w-full h-full bg-black/50 flex items-center justify-center z-50" onClick={() => setShowLowStock(false)}>
          <div className="bg-white p-6 rounded-xl shadow-2xl max-w-md w-full relative" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-lg mb-4 flex items-center text-red-600"><AlertTriangle className="mr-2"/> Low Stock Items</h3>
            <div className="max-h-60 overflow-y-auto">
              {lowStockItems.length === 0 ? (
                <p className="text-gray-500 italic">Inventory is healthy.</p>
              ) : (
                <ul className="space-y-2">
                  {lowStockItems.map(item => (
                    <li key={item.sku} className="flex justify-between items-center border-b pb-2">
                      <div>
                        <div className="font-bold">{item.name}</div>
                        <div className="text-xs text-gray-400">Reorder Point: {item.reorderPoint}</div>
                      </div>
                      <div className="text-red-600 font-bold">{item.stock} Units</div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <button onClick={() => setShowLowStock(false)} className="mt-4 w-full bg-gray-100 hover:bg-gray-200 py-2 rounded text-sm font-bold text-gray-600">Close</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-700 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button onClick={() => setTab('pos')} className="w-full text-left p-3 hover:bg-blue-50 rounded-lg flex items-center text-blue-700 font-medium transition">
              <ShoppingCart size={18} className="mr-3" /> Start New Sale
            </button>
            <button onClick={() => setTab('returns')} className="w-full text-left p-3 hover:bg-blue-50 rounded-lg flex items-center text-blue-700 font-medium transition">
              <Undo2 size={18} className="mr-3" /> Process Return
            </button>
            <button onClick={() => setTab('inventory')} className="w-full text-left p-3 hover:bg-blue-50 rounded-lg flex items-center text-blue-700 font-medium transition">
              <Plus size={18} className="mr-3" /> Receive Delivery
            </button>
            {user.role === 'Owner' && (
              <button onClick={() => setTab('monthend')} className="w-full text-left p-3 hover:bg-purple-50 rounded-lg flex items-center text-purple-700 font-medium transition">
                <CheckSquare size={18} className="mr-3" /> Review Variances
              </button>
            )}
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center justify-center text-gray-400 text-sm">
          <div className="text-center">
             <BarChart3 size={48} className="mx-auto text-gray-300 mb-2"/>
             <p>Sales Trends (Coming Soon)</p>
          </div>
        </div>
      </div>
    </div>
  )
}

// --- RETURNS COMPONENT (UPDATED) ---

function Returns({ inventory, setInventory, returnsLog, setReturnsLog, setSpoilageLog, notify }) {
  const [step, setStep] = useState(1); // 1: Details, 2: Inspection, 3: Refund Method
  const [selectedItemSku, setSelectedItemSku] = useState("");
  const [returnQty, setReturnQty] = useState(1);
  const [returnReason, setReturnReason] = useState("Defective");
  const [isUsable, setIsUsable] = useState(null);

  const selectedItem = inventory.find(i => i.sku === selectedItemSku);
  const refundTotal = selectedItem ? (selectedItem.price * returnQty * 1.15) : 0;

  const handleProceedToInspection = () => {
    if (!selectedItem || returnQty <= 0) {
        notify("Please select a product and valid quantity.");
        return;
    }
    setStep(2);
  };

  const handleInspection = (usable) => {
    setIsUsable(usable);
    setStep(3);
  };

  const processRefund = (method) => {
    // 1. Update Inventory (Only if usable)
    if (isUsable) {
      setInventory(prev => prev.map(i => i.sku === selectedItem.sku ? { ...i, stock: i.stock + parseInt(returnQty) } : i));
    } else {
      // Log Spoilage
      setSpoilageLog(prev => [...prev, { ...selectedItem, qty: returnQty, reason: returnReason, date: new Date().toLocaleDateString() }]);
    }

    // 2. Log Return Transaction
    setReturnsLog(prev => [...prev, { 
      item: selectedItem.name, 
      qty: returnQty,
      amount: refundTotal, 
      method, 
      reason: returnReason,
      usable: isUsable, 
      time: new Date().toLocaleTimeString() 
    }]);

    notify(`Refund of $${refundTotal.toFixed(2)} processed via ${method}.`);
    
    // Reset
    setStep(1);
    setSelectedItemSku("");
    setReturnQty(1);
    setIsUsable(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1 bg-white rounded-xl shadow-lg overflow-hidden min-h-[500px]">
        <div className="bg-orange-600 text-white p-6 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold flex items-center"><Undo2 className="mr-2"/> Product Returns</h2>
            <p className="text-orange-100 text-sm">Process refunds and update inventory.</p>
          </div>
        </div>

        <div className="p-8">
          {/* STEP 1: RETURN DETAILS */}
          {step === 1 && (
            <div className="space-y-6 max-w-md mx-auto">
              <h3 className="font-bold text-gray-700 text-lg border-b pb-2">Return Details</h3>
              
              <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Select Product</label>
                  <select 
                      className="w-full p-3 border rounded-lg bg-gray-50 focus:ring-2 focus:ring-orange-500 outline-none"
                      value={selectedItemSku}
                      onChange={(e) => setSelectedItemSku(e.target.value)}
                  >
                      <option value="">-- Choose Product --</option>
                      {inventory.map(item => (
                          <option key={item.sku} value={item.sku}>
                              {item.name} - ${item.price.toFixed(2)}
                          </option>
                      ))}
                  </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                      <input 
                          type="number" 
                          min="1"
                          className="w-full p-3 border rounded-lg bg-gray-50 focus:ring-2 focus:ring-orange-500 outline-none"
                          value={returnQty}
                          onChange={(e) => setReturnQty(parseInt(e.target.value) || 1)}
                      />
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Reason</label>
                      <select 
                          className="w-full p-3 border rounded-lg bg-gray-50 focus:ring-2 focus:ring-orange-500 outline-none"
                          value={returnReason}
                          onChange={(e) => setReturnReason(e.target.value)}
                      >
                          <option value="Defective">Defective / Damaged</option>
                          <option value="Expired">Expired</option>
                          <option value="Wrong Item">Wrong Item</option>
                          <option value="Customer Changed Mind">Customer Changed Mind</option>
                          <option value="Other">Other</option>
                      </select>
                  </div>
              </div>

              <div className="bg-orange-50 p-4 rounded-lg border border-orange-100 text-center">
                  <div className="text-sm text-orange-600 font-bold uppercase mb-1">Total Refund Amount</div>
                  <div className="text-3xl font-bold text-orange-900">
                      ${refundTotal.toFixed(2)} <span className="text-xs font-normal text-orange-700">(incl. tax)</span>
                  </div>
              </div>

              <button 
                  onClick={handleProceedToInspection}
                  className="w-full bg-orange-600 text-white py-3 rounded-lg font-bold hover:bg-orange-700 transition shadow-md"
                  disabled={!selectedItem}
              >
                  Next: Inspection
              </button>
            </div>
          )}

          {/* STEP 2: INSPECTION */}
          {step === 2 && selectedItem && (
            <div className="text-center space-y-8">
              <h3 className="text-xl font-bold text-gray-800">Inspection: {selectedItem.name} (Qty: {returnQty})</h3>
              <p className="text-gray-600">Is the returned product opened, damaged, or expired?</p>
              
              <div className="grid grid-cols-2 gap-6 max-w-md mx-auto">
                <button 
                  onClick={() => handleInspection(false)}
                  className="p-6 border-2 border-red-100 bg-red-50 rounded-xl hover:border-red-500 transition group"
                >
                  <Trash2 size={40} className="mx-auto text-red-400 mb-2 group-hover:text-red-600"/>
                  <div className="font-bold text-red-800">Damaged / Used</div>
                  <div className="text-xs text-red-600 mt-1">(Spoilage Log)</div>
                </button>

                <button 
                  onClick={() => handleInspection(true)}
                  className="p-6 border-2 border-green-100 bg-green-50 rounded-xl hover:border-green-500 transition group"
                >
                  <RefreshCw size={40} className="mx-auto text-green-400 mb-2 group-hover:text-green-600"/>
                  <div className="font-bold text-green-800">Good Condition</div>
                  <div className="text-xs text-green-600 mt-1">(Restock Inventory)</div>
                </button>
              </div>
              <button onClick={() => setStep(1)} className="text-gray-400 hover:text-gray-600 underline">Back to Details</button>
            </div>
          )}

          {/* STEP 3: REFUND METHOD */}
          {step === 3 && selectedItem && (
            <div className="text-center space-y-8">
              <h3 className="text-xl font-bold text-gray-800">Refund Method</h3>
              <p className="text-gray-600">
                Total Refund Amount: <span className="font-bold text-orange-600">${refundTotal.toFixed(2)}</span>
              </p>
              
              <div className="grid grid-cols-2 gap-6 max-w-md mx-auto">
                <button 
                  onClick={() => processRefund('Cash')}
                  className="p-6 border-2 border-gray-200 rounded-xl hover:bg-green-50 hover:border-green-500 transition group"
                >
                  <DollarSign size={40} className="mx-auto text-green-500 mb-2"/>
                  <div className="font-bold text-gray-800">Cash Refund</div>
                </button>

                <button 
                  onClick={() => processRefund('Card')}
                  className="p-6 border-2 border-gray-200 rounded-xl hover:bg-blue-50 hover:border-blue-500 transition group"
                >
                  <CreditCard size={40} className="mx-auto text-blue-500 mb-2"/>
                  <div className="font-bold text-gray-800">Card Refund</div>
                </button>
              </div>
              <button onClick={() => setStep(2)} className="text-gray-400 hover:text-gray-600 underline">Back to Inspection</button>
            </div>
          )}
        </div>
      </div>

      {/* RETURNS LOG SECTION */}
      <div className="lg:col-span-2 bg-white rounded-xl shadow-lg overflow-hidden h-full">
        <div className="p-4 border-b bg-gray-50">
          <h2 className="font-bold text-gray-700 flex items-center">
            <History className="mr-2"/> Return Log History
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-100 font-bold text-gray-600">
              <tr>
                <th className="p-3">Time</th>
                <th className="p-3">Product</th>
                <th className="p-3 text-center">Qty</th>
                <th className="p-3">Reason</th>
                <th className="p-3 text-right">Refund Amount</th>
                <th className="p-3 text-center">Method</th>
                <th className="p-3 text-center">Restocked?</th>
              </tr>
            </thead>
            <tbody>
              {returnsLog.length === 0 ? (
                <tr><td colSpan="7" className="p-8 text-center text-gray-400 italic">No returns processed yet.</td></tr>
              ) : (
                returnsLog.slice().reverse().map((log, idx) => (
                  <tr key={idx} className="border-b hover:bg-gray-50">
                    <td className="p-3 text-gray-500">{log.time}</td>
                    <td className="p-3 font-medium">{log.item}</td>
                    <td className="p-3 text-center">{log.qty}</td>
                    <td className="p-3">{log.reason}</td>
                    <td className="p-3 text-right text-orange-600 font-bold">-${log.amount.toFixed(2)}</td>
                    <td className="p-3 text-center">
                      <span className={`px-2 py-1 rounded text-xs font-bold ${log.method === 'Cash' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                        {log.method}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      {log.usable ? <span className="text-green-600 font-bold">Yes</span> : <span className="text-red-500 font-bold">No</span>}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function InvoicesList({ invoices, setInvoices, notify }) {
  const [selectedInvoice, setSelectedInvoice] = useState(null);

  const handleAccept = (id) => {
    setInvoices(invoices.map(inv => inv.id === id ? { ...inv, status: 'Paid' } : inv));
    notify(`Invoice ${id} Accepted & Paid ✅`);
    setSelectedInvoice(null);
  };

  const handleReject = (id) => {
    setInvoices(invoices.map(inv => inv.id === id ? { ...inv, status: 'Rejected' } : inv));
    notify(`Invoice ${id} Rejected ❌`);
    setSelectedInvoice(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* List of Invoices */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden h-[70vh] flex flex-col">
        <div className="p-4 border-b bg-gray-50">
          <h2 className="font-bold text-gray-700 flex items-center">
            <FileCheck className="mr-2"/> Supplier Invoices (D3)
          </h2>
        </div>
        <div className="flex-1 overflow-y-auto">
          {invoices.length === 0 ? (
            <div className="p-8 text-center text-gray-400">No invoices found.</div>
          ) : (
            invoices.map(inv => (
              <div 
                key={inv.id}
                onClick={() => setSelectedInvoice(inv)}
                className={`p-4 border-b cursor-pointer hover:bg-blue-50 transition 
                  ${selectedInvoice?.id === inv.id ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''}
                `}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-bold text-gray-800">{inv.supplier}</div>
                    <div className="text-sm text-gray-500">{inv.id} • {inv.date}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-gray-800">${inv.amount.toFixed(2)}</div>
                    <div className={`text-xs font-bold px-2 py-1 rounded inline-block mt-1
                      ${inv.status === 'Pending' ? 'bg-orange-100 text-orange-600' : 
                        inv.status === 'Paid' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}
                    `}>
                      {inv.status}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Invoice Details Panel */}
      <div className="bg-white rounded-xl shadow-sm p-6 h-[70vh] flex flex-col">
        {selectedInvoice ? (
          <>
            <div className="flex justify-between items-start mb-6 border-b pb-4">
              <div>
                <h3 className="text-2xl font-bold text-gray-800">{selectedInvoice.id}</h3>
                <p className="text-gray-500">From: {selectedInvoice.supplier}</p>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-400">Date Received</div>
                <div className="font-bold">{selectedInvoice.date}</div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto mb-6">
              <table className="w-full text-left text-sm">
                <thead className="bg-gray-50 text-gray-500">
                  <tr>
                    <th className="p-2">Item</th>
                    <th className="p-2 text-center">Qty</th>
                    <th className="p-2 text-right">Cost</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedInvoice.items.map((item, idx) => (
                    <tr key={idx} className="border-b">
                      <td className="p-2">{item.name}</td>
                      <td className="p-2 text-center">{item.qty}</td>
                      <td className="p-2 text-right">${item.price.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="border-t pt-4 mb-6">
              <div className="flex justify-between text-xl font-bold">
                <span>Total Due</span>
                <span>${selectedInvoice.amount.toFixed(2)}</span>
              </div>
            </div>

            {selectedInvoice.status === 'Pending' ? (
              <div className="grid grid-cols-2 gap-4 mt-auto">
                <button 
                  onClick={() => handleReject(selectedInvoice.id)}
                  className="py-3 border border-red-200 text-red-600 rounded-lg hover:bg-red-50 font-bold flex justify-center items-center"
                >
                  <XCircle className="mr-2"/> Reject
                </button>
                <button 
                  onClick={() => handleAccept(selectedInvoice.id)}
                  className="py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-bold flex justify-center items-center"
                >
                  <CheckCircle className="mr-2"/> Accept & Pay
                </button>
              </div>
            ) : (
              <div className="mt-auto text-center p-4 bg-gray-50 rounded-lg text-gray-500 italic">
                This invoice has been {selectedInvoice.status.toLowerCase()}.
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <FileText size={64} className="mb-4 opacity-20"/>
            <p>Select an invoice to view details</p>
          </div>
        )}
      </div>
    </div>
  );
}

function EndOfDayReconciliation({ salesLog, inventory, returnsLog = [], notify }) {
  const [step, setStep] = useState(1); 
  const [countedCash, setCountedCash] = useState("");
  const [varianceReason, setVarianceReason] = useState("");
  const [isClosed, setIsClosed] = useState(false);

  const totalSales = salesLog.reduce((acc, s) => acc + s.totals.total, 0);
  
  // Calculate Refunds
  const totalCashRefunds = returnsLog.filter(r => r.method === 'Cash').reduce((acc, r) => acc + r.amount, 0);
  const totalCardRefunds = returnsLog.filter(r => r.method === 'Card').reduce((acc, r) => acc + r.amount, 0);

  // Net Calculations
  const totalCashSales = salesLog.filter(s => s.method === 'Cash').reduce((acc, s) => acc + s.totals.total, 0);
  const netCash = totalCashSales - totalCashRefunds;

  const totalCardSales = salesLog.filter(s => s.method === 'Card').reduce((acc, s) => acc + s.totals.total, 0);
  const netCard = totalCardSales - totalCardRefunds;
  
  const categoryBreakdown = salesLog.reduce((acc, sale) => {
    sale.items.forEach(item => {
      const cat = item.category;
      const total = item.price * item.qty;
      acc[cat] = (acc[cat] || 0) + total;
    });
    return acc;
  }, {});

  const productSales = salesLog.reduce((acc, sale) => {
    sale.items.forEach(item => {
      if (!acc[item.sku]) {
        const currentStock = inventory.find(i => i.sku === item.sku)?.stock || 0;
        const reorderPoint = inventory.find(i => i.sku === item.sku)?.reorderPoint || 0;
        acc[item.sku] = { 
          name: item.name, 
          qty: 0, 
          total: 0, 
          currentStock, 
          isLow: currentStock <= reorderPoint 
        };
      }
      acc[item.sku].qty += item.qty;
      acc[item.sku].total += (item.price * item.qty);
    });
    return acc;
  }, {});

  const lotterySales = categoryBreakdown['Lottery'] || 0;
  const otherSales = totalSales - lotterySales;

  const variance = (parseFloat(countedCash) || 0) - netCash;
  const hasVariance = Math.abs(variance) > 0.01;

  const varianceOptions = ["Forgot to ring up item", "Change error", "Theft suspected", "Lottery Payout Mismatch", "Other"];

  const handleCloseDay = () => {
    setIsClosed(true);
    notify("Day Closed! Z-Report generated and stored (D1).");
  };

  if (isClosed) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-10 text-center">
        <div className="inline-block p-4 bg-green-100 rounded-full mb-4"><CheckCircle size={64} className="text-green-600"/></div>
        <h2 className="text-2xl font-bold text-gray-800">Day Successfully Closed!</h2>
        <p className="text-gray-500 mt-2">Z-Report #2025-06-24 has been archived.</p>
        <button onClick={() => setIsClosed(false)} className="mt-6 text-blue-600 hover:underline">View Report History</button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="bg-blue-900 text-white p-6 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold flex items-center"><FileText className="mr-2"/> End of Day Reconciliation (P4)</h2>
          <p className="text-blue-200 text-sm">Follow the steps to close the register.</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold">${(totalSales - totalCashRefunds - totalCardRefunds).toFixed(2)}</div>
          <div className="text-xs text-blue-300 uppercase">Net Total Sales</div>
        </div>
      </div>

      <div className="p-8">
        <div className="flex items-center justify-center mb-8 space-x-4">
          <StepPill num={1} label="Sales Summary" active={step === 1} done={step > 1} />
          <div className="w-8 h-0.5 bg-gray-200"></div>
          <StepPill num={2} label="Product Detail" active={step === 2} done={step > 2} />
          <div className="w-8 h-0.5 bg-gray-200"></div>
          <StepPill num={3} label="Cash Count" active={step === 3} done={step > 3} />
          <div className="w-8 h-0.5 bg-gray-200"></div>
          <StepPill num={4} label="Finalize" active={step === 4} done={step > 4} />
        </div>

        {/* STEP 1: CATEGORY BREAKDOWN */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h3 className="font-bold text-gray-700 mb-3 border-b pb-2">Payment Methods</h3>
                <div className="flex justify-between mb-1"><span>Cash Sales</span><span className="font-mono font-bold">${totalCashSales.toFixed(2)}</span></div>
                <div className="flex justify-between mb-2 text-xs text-red-500 border-b pb-2"><span>- Refunds (Cash)</span><span>-${totalCashRefunds.toFixed(2)}</span></div>
                <div className="flex justify-between mb-4"><span>Net Cash</span><span className="font-mono font-bold text-green-700">${netCash.toFixed(2)}</span></div>

                <div className="flex justify-between mb-1"><span>Card Sales</span><span className="font-mono font-bold">${totalCardSales.toFixed(2)}</span></div>
                <div className="flex justify-between mb-2 text-xs text-red-500 border-b pb-2"><span>- Refunds (Card)</span><span>-${totalCardRefunds.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Net Card</span><span className="font-mono font-bold text-blue-700">${netCard.toFixed(2)}</span></div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h3 className="font-bold text-gray-700 mb-3 border-b pb-2">Sales by Category</h3>
                <div className="flex justify-between mb-2"><span>Lottery Sales</span><span className="font-mono font-bold">${lotterySales.toFixed(2)}</span></div>
                <div className="flex justify-between mb-2"><span>Other Items</span><span className="font-mono font-bold">${otherSales.toFixed(2)}</span></div>
              </div>
            </div>
            <button onClick={() => setStep(2)} className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 flex items-center justify-center">
              Next: Product Details <ArrowRight size={18} className="ml-2"/>
            </button>
          </div>
        )}

        {/* STEP 2: PRODUCT DETAIL */}
        {step === 2 && (
          <div className="space-y-6">
            <h3 className="font-bold text-gray-700 flex items-center"><List className="mr-2"/> Detailed Product Sales</h3>
            <div className="overflow-y-auto max-h-64 border rounded-lg">
              <table className="w-full text-left text-sm">
                <thead className="bg-gray-100 font-bold text-gray-600 sticky top-0">
                  <tr>
                    <th className="p-3">Product</th>
                    <th className="p-3 text-center">Qty Sold</th>
                    <th className="p-3 text-right">Revenue</th>
                    <th className="p-3 text-center">Stock Status</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(productSales).length === 0 ? (
                    <tr><td colSpan="4" className="p-4 text-center text-gray-400">No items sold today.</td></tr>
                  ) : (
                    Object.entries(productSales).map(([sku, data]) => (
                      <tr key={sku} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-medium">{data.name}</td>
                        <td className="p-3 text-center">{data.qty}</td>
                        <td className="p-3 text-right">${data.total.toFixed(2)}</td>
                        <td className="p-3 text-center">
                          {data.isLow ? (
                            <span className="bg-red-100 text-red-600 px-2 py-1 rounded text-xs font-bold flex items-center justify-center">
                              <AlertTriangle size={10} className="mr-1"/> LOW ({data.currentStock})
                            </span>
                          ) : (
                            <span className="text-gray-400 text-xs">OK ({data.currentStock})</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            <div className="flex space-x-3">
              <button onClick={() => setStep(1)} className="flex-1 py-3 text-gray-600 hover:bg-gray-100 rounded-lg">Back</button>
              <button onClick={() => setStep(3)} className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700">Next: Count Cash</button>
            </div>
          </div>
        )}

        {/* STEP 3: COUNT CASH */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="text-center">
              <div className="bg-blue-50 inline-block p-4 rounded-full mb-4"><DollarSign size={32} className="text-blue-600"/></div>
              <h3 className="font-bold text-gray-800">Count Drawer Cash</h3>
              <p className="text-sm text-gray-500">Please count the physical cash (net after refunds) and enter it below.</p>
            </div>
            <div className="max-w-xs mx-auto relative">
              <span className="absolute left-3 top-3 text-gray-400">$</span>
              <input type="number" value={countedCash} onChange={(e) => setCountedCash(e.target.value)} className="w-full pl-8 pr-4 py-3 border-2 border-gray-300 rounded-lg text-xl font-bold focus:border-blue-500 outline-none" placeholder="0.00"/>
            </div>
            {countedCash && (
              <div className={`p-4 rounded-lg border ${hasVariance ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}>
                <div className="flex justify-between items-center"><span className="text-sm font-bold text-gray-600">System Net Cash:</span><span className="font-mono">${netCash.toFixed(2)}</span></div>
                <div className="flex justify-between items-center mt-2"><span className="text-sm font-bold text-gray-600">Variance:</span><span className={`font-bold font-mono ${hasVariance ? 'text-red-600' : 'text-green-600'}`}>{variance > 0 ? '+' : ''}{variance.toFixed(2)}</span></div>
              </div>
            )}
            {hasVariance && (
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Explain Variance (Required)</label>
                <select className="w-full p-3 border border-gray-300 rounded-lg focus:border-red-500 outline-none text-sm bg-white" value={varianceReason} onChange={(e) => setVarianceReason(e.target.value)}>
                  <option value="">Select a reason...</option>
                  {varianceOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              </div>
            )}
            <div className="flex space-x-3">
              <button onClick={() => setStep(2)} className="flex-1 py-3 text-gray-600 hover:bg-gray-100 rounded-lg">Back</button>
              <button onClick={() => setStep(4)} disabled={!countedCash || (hasVariance && !varianceReason)} className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 disabled:opacity-50">Next: Finalize</button>
            </div>
          </div>
        )}

        {/* STEP 4: FINALIZE */}
        {step === 4 && (
          <div className="space-y-6 text-center">
            <h3 className="font-bold text-gray-800">Confirm & Close</h3>
            <p className="text-sm text-gray-500">You are about to generate the Z-Report and close the day.</p>
            <div className="bg-gray-100 p-6 rounded-lg text-left space-y-2 max-w-sm mx-auto text-sm">
              <div className="flex justify-between"><span>Date:</span> <span className="font-bold">{new Date().toLocaleDateString()}</span></div>
              <div className="flex justify-between"><span>Total Sales:</span> <span className="font-bold">${totalSales.toFixed(2)}</span></div>
              <div className="flex justify-between text-red-500"><span>Total Refunds:</span> <span className="font-bold">-${(totalCashRefunds + totalCardRefunds).toFixed(2)}</span></div>
              <div className="flex justify-between border-t pt-1 mt-1"><span>Net Cash Expected:</span> <span className="font-bold">${netCash.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Cash Counted:</span> <span className="font-bold">${parseFloat(countedCash).toFixed(2)}</span></div>
              <div className="flex justify-between border-t pt-2"><span>Variance:</span> <span className={`font-bold ${hasVariance ? 'text-red-600' : 'text-green-600'}`}>{variance.toFixed(2)}</span></div>
            </div>
            <button onClick={handleCloseDay} className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-700 shadow-lg transform hover:scale-105 transition">Confirm Close Day</button>
          </div>
        )}
      </div>
    </div>
  );
}

function MonthEndReconciliation({ mockData, notify }) {
  const [step, setStep] = useState(1); 
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Calculate financials
  const totalRevenue = mockData.reduce((acc, d) => acc + d.sales, 0);
  const totalCOGS = mockData.reduce((acc, d) => acc + (d.cost || 0), 0); // Mock data now has cost
  const grossProfit = totalRevenue - totalCOGS;

  const startCollection = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setStep(2);
      setIsProcessing(false);
    }, 2000);
  };

  const sendReport = () => {
    notify("Report Sent to Accountant 📧");
  };

  const printReport = () => {
    notify("Printing Report... 🖨️");
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden min-h-[600px]">
      <div className="bg-purple-900 text-white p-8 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center">
            <Archive className="mr-3"/> Month-End Reconciliation (P5)
          </h2>
          <p className="text-purple-200 mt-2">June 2025 Closing Process</p>
        </div>
        <Calendar size={48} className="text-purple-800 opacity-50"/>
      </div>

      <div className="p-8">
        <div className="flex items-center justify-center mb-10 space-x-4">
          <StepPill num={1} label="Collect Data" active={step === 1} done={step > 1} />
          <div className="w-8 h-0.5 bg-gray-200"></div>
          <StepPill num={2} label="Review Financials" active={step === 2} done={step > 2} />
        </div>

        {/* STEP 1: COLLECT */}
        {step === 1 && (
          <div className="text-center py-12">
            <div className="max-w-md mx-auto bg-purple-50 p-8 rounded-xl border border-purple-100">
              <h3 className="text-lg font-bold mb-4 text-purple-900">Ready to Close Month?</h3>
              <p className="text-gray-600 mb-6 text-sm">
                This will gather all sales, inventory, and invoice data for the accountant.
              </p>
              <button 
                onClick={startCollection}
                disabled={isProcessing}
                className="bg-purple-600 text-white px-8 py-3 rounded-full font-bold hover:bg-purple-700 disabled:opacity-50 flex items-center justify-center w-full transition-all hover:scale-105"
              >
                {isProcessing ? <RefreshCw className="animate-spin mr-2"/> : <ArrowRight className="mr-2"/>}
                {isProcessing ? "Collecting Data..." : "Start Collection"}
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: FINANCIAL REVIEW (NEW) */}
        {step === 2 && (
          <div className="space-y-8">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Month-End Financial Summary</h3>
              <p className="text-gray-500">June 2025 • Preliminary Figures</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-blue-50 p-6 rounded-xl border border-blue-100 text-center">
                <div className="text-sm text-blue-600 font-bold uppercase mb-1">Total Sales Revenue</div>
                <div className="text-3xl font-bold text-blue-900">${totalRevenue.toFixed(2)}</div>
              </div>
              <div className="bg-orange-50 p-6 rounded-xl border border-orange-100 text-center">
                <div className="text-sm text-orange-600 font-bold uppercase mb-1">Cost of Goods Sold (COGS)</div>
                <div className="text-3xl font-bold text-orange-900">-${totalCOGS.toFixed(2)}</div>
              </div>
              <div className="bg-green-50 p-6 rounded-xl border border-green-100 text-center">
                <div className="text-sm text-green-600 font-bold uppercase mb-1">Gross Profit</div>
                <div className="text-3xl font-bold text-green-900 flex items-center justify-center">
                  <TrendingUp size={24} className="mr-2"/> ${grossProfit.toFixed(2)}
                </div>
              </div>
            </div>

            <div className="flex justify-center space-x-6 pt-8 border-t">
              <button 
                onClick={sendReport}
                className="flex items-center px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-bold shadow-md"
              >
                <Send size={20} className="mr-2"/> Send to Accountant
              </button>

              <button 
                onClick={printReport}
                className="flex items-center px-6 py-3 bg-white border-2 border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 font-bold shadow-sm"
              >
                <Printer size={20} className="mr-2"/> Print Report
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}